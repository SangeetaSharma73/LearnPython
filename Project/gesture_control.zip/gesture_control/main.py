import cv2
import cvzone
from cvzone.HandTrackingModule import HandDetector
import serial
import time

# Initialize the serial connection to Arduino
ser = serial.Serial('COM5', 9600)  # Change as needed
time.sleep(2)

# Initialize webcam and hand detector
cap = cv2.VideoCapture(0)
detector = HandDetector(detectionCon=0.8, maxHands=1)

last_command = ""  # For latching gesture on Python side

def control_op(command):
    global last_command
    if command != last_command:  # Only send if new
        ser.write(f"{command}\n".encode())
        last_command = command

while True:
    success, img = cap.read()
    if not success:
        print("Failed to capture image")
        break

    hands, img = detector.findHands(img)

    if hands:
        hand = hands[0]
        fingers = detector.fingersUp(hand)

        # Detect gesture and latch if changed
        if fingers == [0, 1, 0, 0, 0]:
            control_op("ONE")
        elif fingers == [0, 1, 1, 0, 0]:
            control_op("TWO")
        elif fingers == [0, 1, 1, 1, 0]:
            control_op("THREE")
        elif fingers == [0, 1, 1, 1, 1]:
            control_op("FOUR")
        elif fingers == [1, 1, 1, 1, 1]:
            control_op("FIVE")  
        else:
            pass  # No change on unknown gesture
    else:
        pass  # Hand removed — do not send anything

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
ser.close()